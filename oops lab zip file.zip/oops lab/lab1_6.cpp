#include <stdio.h>
#include<stdlib.h>
int main()
{
char *p,*t;
int i,j,k=0;
p=(char*)malloc(sizeof(char));
t=(char*)malloc(sizeof(char));
scanf("%s",p);
scanf("%s",t);
for(i=0;p[i]!='\0';i++);

for(j=i;t[k]!='\0';j++,k++)
{
    p[j]=t[k];
}
p[j]='\0';
printf("%s",p);

return 0;
}
