#include<iostream>
using namespace std;
int main()
{
int i,j,rem=1,k=1;
cout<<"Enter any value of i"<<endl;
cin>>i;
cout<<"Enter any value of j"<<endl;
cin>>j;
while(rem<=i)
{
    rem=k*j;
    k++;
}
cout<<"After rounding of "<<i<<" the value becomes "<<rem<<endl;
return 0;
}
