#include<iostream>
#include<math.h>
#include<conio.h>
using namespace std;
int main()
{
    int i=32,a[4],k;
    long int j;
    while(i<100)
    {
        j=i*i;
        k=0;
        while(j>0)
        {
            a[k]=j%10;
            j=j/10;
            k++;
        }
    if((a[0]==a[1]&&a[2]==a[3]))
        cout<<"The number is "<<i*i<<endl;
    i++;
    }
getch();
return 0;
}
