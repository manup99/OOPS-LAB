#include<iostream>
using namespace std;
int main()
{
int i,j;
cout<<"Enter any value of i"<<endl;
cin>>i;
rem=i%7;
switch(rem)
{
case 1:
{
cout<<"The value of integer j is "i+6;
}
break;
case 2:
{
cout<<"The value of integer j is "<<i+5;
}
break;
case 3:
{
cout<<"The value of integer j is "<<i+4;
}
break;
case 4:
{
cout<<"The value of integer j is "<<i+3;
}
break;
case 5:
{
cout<<"The value of integer j is "<<i+2;
}
break;
case 6:
{
cout<<"The value of integer j is "<<i+1;
}
break;
case 0:
{
cout<<"The value of integer j is remains same as it is already rounded off\n";
}
}
return 0;
}
