#include<iostream>
using namespace std;
class fact
{
long int x;
public:
long int factorial(long int);
};
long int fact::factorial(long int z)
{
x=z;
if(x>=1)
return(x*factorial(x-1));
else
return 1;
}
int main()
{
fact f;
long int j;
cout<<"Enter any value\n";
cin>>j;
cout<<"The factorial of entered number is "<<f.factorial(j);
return 0;
}
