#include<iostream>
using namespace std;
int main()
{
long int x;
int c=0;
cout<<"Enter any value of x"<<endl;
cin>>x;
while(x>0)
{
x=x/10;
c++;
}
cout<<"The number of digits in x is "<<c<<endl;
return 0;
}
