#include<iostream>
using namespace std;
int main()
{
char s[20];
int i;
cout<<"Enter any string\n";
cin>>s;
for(i=0;s[i]!='\0';i++);
cout<<"The lenght of string is "<<i<<endl;
return 0;
}
